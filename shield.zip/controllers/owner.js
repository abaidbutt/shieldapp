const Owner = require("../models/Owner");
const Employee = require("../models/Employee");
const bcrypt = require("bcryptjs");
const dotenv = require("dotenv");
const jwt = require("jsonwebtoken");
dotenv.config();
exports.signupController = async (req, res) => {
  const { body } = req;
  try {
    console.log(body);
    const user = await Owner.findOne({ mobileNumber: body.mobileNumber });
    if (user) {
      return res
        .status(400)
        .json({ status: false, message: "Mobile Number is already exist" });
    }
    const newUser = new Owner(body);
    console.log(newUser.password);

    const salt = await bcrypt.genSalt(10);
    newUser.password = await bcrypt.hash(newUser.password, salt);

    await newUser.save();

    res.json({
      status: true,
      message: "Register Successfully.. Now go to SignIn",
    });
  } catch (error) {
    console.log(error, "this owner error confirm not");
    res.status(500).json({
      status: false,
      message: "Server Error while creating new user",
    });
  }
};
exports.signinController = async (req, res) => {
  const { mobileNumber, password } = req.body;
  try {
    const user = await Owner.findOne({ mobileNumber });
    console.log(user);
    if (!user) {
      return res.status(400).json({
        status: false,
        message: "Invalid  Mobile Number",
      });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({
        status: false,
        message: "Invalid  Password",
      });
    }
    const payload = {
      user: {
        _id: user._id,
      },
    };

    jwt.sign(
      payload,
      process.env.JWTSECRET,
      { expiresIn: process.env.JWTEXPIRE },
      (err, token) => {
        if (err) console.log("Jwt error", err);
        const { _id, mobileNumber, firstName, lastName } = user;

        res.json({
          token,
          user: { _id, mobileNumber, firstName, lastName, role: "owner" },
        });
      }
    );
  } catch (error) {
    console.log("Server Error while checking this user", error);
    res.status(500).json({
      status: false,
      message: "Server Error while checking this user",
    });
  }
};
exports.employeeSearch = async (req, res) => {
  try {
    const { name } = req.body;
    console.log(name);
    const employees = await Employee.find({
      $or: [
        { firstName: { $regex: name, $options: "i" } },
        { lastName: { $regex: name, $options: "i" } },
      ],
    });

    res.json({ employees });
    res.send(name);
  } catch (error) {
    console.log("Error when fetching product", error);
    res.status(500).json({
      message: "Please try later",
    });
  }
};
