const Employee = require("../models/Employee");
const bcrypt = require("bcryptjs");
const dotenv = require("dotenv");
const jwt = require("jsonwebtoken");
const { streamUpload } = require("../middleware/memoryUpload");
const streamifier = require("streamifier");
const { config, uploader } = require("cloudinary").v2;
config({
  cloud_name: "abaidbutt",
  api_key: "311236173867714",
  api_secret: "WV5dKB4_5_Dv_jIoX9zLsMzwILM",
});

dotenv.config();
exports.signupController = async (req, res) => {
  const { body } = req;
  try {
    const user = await Employee.findOne({ mobileNumber: body.mobileNumber });
    if (user) {
      return res
        .status(400)
        .json({ status: false, message: "Mobile Number is already exist" });
    }
    const newUser = new Employee(body);

    const salt = await bcrypt.genSalt(10);
    newUser.password = await bcrypt.hash(newUser.password, salt);

    await newUser.save();

    res.json({
      status: true,
      message: "Register Successfully.. Now go to SignIn",
    });
  } catch (error) {
    res.status(500).json({
      status: false,
      message: "Server Error while creating new user",
    });
  }
};
exports.signinController = async (req, res) => {
  const { mobileNumber, password } = req.body;
  try {
    const user = await Employee.findOne({ mobileNumber });
    console.log(user);
    if (!user) {
      return res.status(400).json({
        status: false,
        message: "Invalid  Mobile Number",
      });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({
        status: false,
        message: "Invalid  Password",
      });
    }
    const payload = {
      user: {
        _id: user._id,
      },
    };

    jwt.sign(
      payload,
      process.env.JWTSECRET,
      { expiresIn: process.env.JWTEXPIRE },
      (err, token) => {
        if (err) console.log("Jwt error", err);
        const { _id, mobileNumber, firstName, lastName } = user;

        res.json({
          token,
          user: { _id, mobileNumber, firstName, lastName, role: "employee" },
        });
      }
    );
  } catch (error) {
    console.log("Server Error while checking this user", error);
    res.status(500).json({
      status: false,
      message: "Server Error while checking this user",
    });
  }
};

exports.imageController = async (req, res) => {
  try {
    let {
      rent_agreement_img,
      vaccine_img1,
      vaccine_img2,
      a_adharImage,
      camImage,
    } = req.files;
    rent_agreement_img = rent_agreement_img[0]?.path;
    vaccine_img1 = vaccine_img1[0]?.path;
    vaccine_img2 = vaccine_img2[0]?.path;
    a_adharImage = a_adharImage[0]?.path;
    camImage = camImage[0]?.path;

    const rent_img = await uploader.upload(
      rent_agreement_img,
      function (error, result) {
        return result;
      }
    );

    const vac_img1 = await uploader.upload(
      vaccine_img1,
      function (error, result) {
        return result;
      }
    );
    const vac_img2 = await uploader.upload(
      vaccine_img2,
      function (error, result) {
        return result;
      }
    );

    const adhr_img = await uploader.upload(
      a_adharImage,
      function (error, result) {
        return result;
      }
    );

    const check = await Employee.findOneAndUpdate(
      { _id: userId },
      {
        rent_agreement_img: rent_img?.url,
        vaccine_img1: vac_img1?.url,
        vaccine_img2: vac_img2?.url,
        a_adharImage: adhr_img?.url,
      },
      {
        new: true,
      }
    );
    console.log(check);
    res.json({
      status: true,
      message: `user save the image, `,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({
      status: false,
      message: "Server Error while creating new user",
    });
  }
};

exports.historyController = async (req, res) => {
  const { body } = req;
  try {
    console.log(body);
    const orgainzation = await Employee.findOneAndUpdate(
      { _id: body?.userId },
      {
        $addToSet: {
          previous: {
            organization: body?.organization,
            reason: body?.reason,
            remark: body?.remark,
            rating: body?.rating,
            endDate: body?.endDate,
            joinDate: body?.joinDate,
          },
        },
      },
      { upsert: true }
    );
    console.log(orgainzation, "error");
    res.json({
      status: true,
      message: "User Historical Date updated",
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({
      status: false,
      message: "Server Error while creating new user",
    });
  }
};
