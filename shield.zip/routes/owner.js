const express = require("express");
const router = express.Router();
const {
  signupController,
  signinController,
  employeeSearch,
} = require("../controllers/owner");

router.post("/signup", signupController);
router.post("/signin", signinController);
router.get("/employeeSearch", employeeSearch);

module.exports = router;
