const express = require("express");
const app = express();
var http = require("http");
const cors = require("cors");
const port = process.env.PORT || 5000;

const router = express.Router();
const connectDB = require("./database/db");
const ownerRoutes = require("./routes/owner");
const entityRoutes = require("./routes/entity");
const serviceRoutes = require("./routes/service");
const providerServiceRoutes = require("./routes/providerService");
const employeeRoutes = require("./routes/employee");
const providerRoutes = require("./routes/provider");
const bodyParser = require("body-parser");
const twilio = require("twilio");
const accountSid = "AC38eb72820f21094ce79450c0d19df8c0"; // Your Account SID from www.twilio.com/console
const authToken = "88a807f3213314804e674f7fea4e19cb"; // Your Auth Token from www.twilio.com/console
// const accountSid = "SK19d5136c1dd67a70edbb93d101ad5221"; // Your Account SID from www.twilio.com/console
// const authToken = "7JCVhjCAxN3vR7CeAOjOIG3Kqq485FhM"; // Your Auth Token from www.twilio.com/console

const client = new twilio(accountSid, authToken);

connectDB();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
// app.use((req, res, next) => {
//   res.setHeader("Access-Control-Allow-Origin", "*");
//   res.setHeader("Access-Control-Allow-Credentials", true);
//   res.setHeader("Access-Control-Allow-Methods", [
//     "PATCH",
//     "POST",
//     "GET",
//     "DELETE",
//     "PUT",
//   ]);
//   res.setHeader("Access-Control-Allow-Headers", ["Content-Type"]);
//   res.setHeader("Access-Control-Expose-Headers", ["Content-Type"]);
//   next();
// });
app.use("/uploads", express.static("uploads"));
app.use("/api/owner", ownerRoutes);
app.use("/api/entity", entityRoutes);
app.use("/api/service", serviceRoutes);
app.use("/api/providerService", providerServiceRoutes);
app.use("/api/employee", employeeRoutes);
app.use("/api/provider", providerRoutes);
app.use("/api/number", async (req, res) => {
  try {
    const { name, number } = req.body;
    client.verify
      .services("VA61ea528de1faaec94d6317e55fe1191a")
      .verifications.create({ to: "+923111715499", channel: "sms" })
      .then((verification) => console.log(verification.sid, "rakjda"));

    console.log(number);
    res.json({ message: "ok" });
  } catch (err) {
    console.log(err);
    res.json({ message: "Server Error" });
  }
});
app.use((error, req, res, next) => {
  console.log("This is the rejected field ->", error);
});
app.use("/hello", (req, res) => {
  res.send("hello from nassir");
});
var httpServer = http.createServer(app);

httpServer.listen(port, () => console.log(`listning on port ${port}`));
